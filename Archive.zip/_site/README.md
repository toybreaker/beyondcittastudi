# [Ultra/beyond Città Studi](beyondcittastudi.org)
Crowdsourcing Architecture Contest  website

Developed for [Politecnico di Milano](http://www.polimi.it/en/english-version/)


## Website credits:

- open source website by [Jungle ★ Star](http://junglestar.org)

- [Smashicons](http://smashicons.com/) via [the noun project](https://thenounproject.com) by [Oliviu sStoian](https://thenounproject.com/oliviustoian/)

- free [ Open Street Map  ](https://www.openstreetmap.org) vector map

- conditional media queries mixin by [Sheiko](http://dsheiko.com)
